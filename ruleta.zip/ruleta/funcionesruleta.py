import random
import tkinter as tk


apuestas = {"negro": 0, "rojo": 0, "verde": 0}
resultados = []
ganancias_totales = 0


def suma_digitos(numero):
    return sum(int(digito) for digito in str(numero))


def girar_ruleta(resultado_label, apuesta_label, ganancias_label, resultados_label):
    global ganancias_totales
    numero = random.randint(0, 36)
    resultado_label.config(text=f"{numero}")
    suma = suma_digitos(numero)
    color_resultado = ""
    if numero == 0:
        resultado_label.config(bg="#20C073", fg="white", relief="solid", bd=0)
        color_resultado = "Verde"
        ganancias_totales += apuestas["verde"] * 36
    elif suma % 2 == 0:
        resultado_label.config(bg="black", fg="white", relief="solid", bd=0)
        color_resultado = "Negro"
        ganancias_totales += apuestas["negro"] * 2
    else:
        resultado_label.config(bg="#C61F2B", fg="white", relief="solid", bd=0)
        color_resultado = "Rojo"
        ganancias_totales += apuestas["rojo"] * 2
    if color_resultado != "Verde":
        ganancias_totales -= apuestas["verde"]
    if color_resultado != "Negro":
        ganancias_totales -= apuestas["negro"]
    if color_resultado != "Rojo":
        ganancias_totales -= apuestas["rojo"]
    apuestas["negro"] = apuestas["rojo"] = apuestas["verde"] = 0
    apuesta_label.config(text=f"Apuestas: Negro: {apuestas['negro']} | Rojo: {apuestas['rojo']} | Verde: {apuestas['verde']}")
    resultados.append(f"{color_resultado} (Número: {numero}) - Apuesta: {apuestas[color_resultado.lower()]}€")
    if len(resultados) > 10:
        resultados.pop(0)
    actualizar_resultados(resultados_label)
    ganancias_label.config(text=f"Ganancias/Pérdidas Totales: {ganancias_totales}€")


def apostar(color, cantidad_entry, apuesta_label):
    try:
        cantidad = int(cantidad_entry.get())
        if cantidad > 0:
            apuestas[color] += cantidad
            apuesta_label.config(text=f"Apuestas: Negro: {apuestas['negro']} | Rojo: {apuestas['rojo']} | Verde: {apuestas['verde']}")
            cantidad_entry.delete(0, tk.END)
    except ValueError:
        pass


def quitar_apuestas(apuesta_label, ganancias_label, resultados_label):
    global ganancias_totales
    for color in apuestas:
        apuestas[color] = 0
    ganancias_totales = 0
    apuesta_label.config(text="Apuestas: Negro: 0 | Rojo: 0 | Verde: 0")
    ganancias_label.config(text="Ganancias/Pérdidas Totales: 0€")
    resultados.clear()
    actualizar_resultados(resultados_label)


def actualizar_resultados(resultados_label):
    if resultados:
        resultados_label.config(text="Resultados: " + "\n".join(resultados))
    else:
        resultados_label.config(text="Resultados: ")