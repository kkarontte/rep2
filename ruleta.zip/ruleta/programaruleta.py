import tkinter as tk
from funcionesruleta import girar_ruleta, apostar, quitar_apuestas

apuestas = {"negro": 0, "rojo": 0, "verde": 0}
resultados = []
ganancias_totales = 0

ventana = tk.Tk()
ventana.title("Ruleta de Casino")

resultado_label = tk.Label(ventana, text="", font=("Helvetica", 75), width=5, height=2)
resultado_label.pack(pady=20)

girar_button = tk.Button(ventana, text="Girar Ruleta", command=lambda: girar_ruleta(resultado_label, apuesta_label, ganancias_label, resultados_label))
girar_button.pack(pady=10)

cantidad_entry = tk.Entry(ventana, font=("Helvetica", 16), width=10)
cantidad_entry.pack(pady=10)

boton_negro = tk.Button(ventana, text="Apostar a Negro", command=lambda: apostar("negro", cantidad_entry, apuesta_label))
boton_negro.pack(pady=5)

boton_rojo = tk.Button(ventana, text="Apostar a Rojo", command=lambda: apostar("rojo", cantidad_entry, apuesta_label))
boton_rojo.pack(pady=5)

boton_verde = tk.Button(ventana, text="Apostar a Verde", command=lambda: apostar("verde", cantidad_entry, apuesta_label))
boton_verde.pack(pady=5)

quitar_apuestas_button = tk.Button(ventana, text="Quitar Apuestas", command=lambda: quitar_apuestas(apuesta_label, ganancias_label, resultados_label))
quitar_apuestas_button.pack(pady=5)

resultados_label = tk.Label(ventana, text="Resultados: ", font=("Helvetica", 16), justify="left")
resultados_label.pack(pady=10)

apuesta_label = tk.Label(ventana, text="Apuestas: Negro: 0 | Rojo: 0 | Verde: 0", font=("Helvetica", 16))
apuesta_label.pack(pady=20)

ganancias_label = tk.Label(ventana, text="Ganancias/Pérdidas Totales: 0€", font=("Helvetica", 16))
ganancias_label.pack(pady=20)

ventana.mainloop()